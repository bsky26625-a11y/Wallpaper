package com.example.csexamwallpaper

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import android.os.Handler
import android.os.Looper

class ExamWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = ExamEngine()

    private data class Exam(val date: LocalDate, val code: String, val subject: String)
    private val exams = listOf(
        Exam(LocalDate.of(2026,12,6),"25911","Mathematics-I"),
        Exam(LocalDate.of(2026,12,7),"25711","Bangla-I"),
        Exam(LocalDate.of(2026,12,8),"25712","English-I"),
        Exam(LocalDate.of(2026,12,9),"25912","Physics-I"),
        Exam(LocalDate.of(2026,12,10),"","=="),
        Exam(LocalDate.of(2026,12,13),"26711","Basic Electricity"),
        Exam(LocalDate.of(2026,12,14),"","==")
    )

    inner class ExamEngine : Engine() {
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF10251D.toInt() }
        private val green = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF244C36.toInt() }
        private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF5FFF7.toInt(); textAlign = Paint.Align.CENTER }
        private val muted = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFB7DCC7.toInt(); textAlign = Paint.Align.CENTER }
        private val lime = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFC9FFB7.toInt(); textAlign = Paint.Align.CENTER; typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
        private var visible = false
        private val handler = Handler(Looper.getMainLooper())
        private val refreshTask = object : Runnable {
            override fun run() {
                if (visible) {
                    drawFrame()
                    handler.postDelayed(this, 60_000L)
                }
            }
        }
        private val dateFormat = DateTimeFormatter.ofPattern("d MMMM yyyy", Locale("bn","BD"))

        override fun onVisibilityChanged(visibleNow: Boolean) {
            visible = visibleNow
            handler.removeCallbacks(refreshTask)
            if (visible) {
                drawFrame()
                handler.postDelayed(refreshTask, 60_000L)
            }
        }
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(refreshTask)
            super.onSurfaceDestroyed(holder)
        }
        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(refreshTask)
            super.onDestroy()
        }

        private fun drawFrame() {
            if (!visible) return
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) drawContent(canvas)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun drawContent(c: Canvas) {
            val w=c.width.toFloat(); val h=c.height.toFloat()
            c.drawColor(bg.color)
            val scale=w/440f
            c.save(); c.scale(scale,scale)
            val cw=440f; val ch=h/scale
            white.textSize=17f; muted.textSize=15f; lime.textSize=31f
            c.drawText("DINAJPUR POLYTECHNIC INSTITUTE",cw/2, ch*.18f,muted)
            white.textSize=28f
            c.drawText("MID SEMESTER EXAM",cw/2,ch*.23f,white)
            c.drawText("1st Semester · Computer Science",cw/2,ch*.27f,muted)
            val today=LocalDate.now()
            white.textSize=18f
            c.drawText("আজ: "+today.format(dateFormat),cw/2,ch*.34f,white)
            val next=exams.firstOrNull{!it.date.isBefore(today)}
            val top=ch*.41f; val bottom=ch*.70f
            c.drawRoundRect(24f,top,cw-24f,bottom,24f,24f,green)
            muted.textSize=16f
            c.drawText(if(next?.date==today) "আজকের পরীক্ষা" else "পরবর্তী পরীক্ষা",cw/2,top+42f,muted)
            white.textSize=25f
            c.drawText(next?.subject ?: "পরীক্ষা শেষ",cw/2,top+88f,white)
            muted.textSize=16f
            c.drawText(next?.date?.format(dateFormat) ?: "সব পরীক্ষার তারিখ পার হয়েছে",cw/2,top+122f,muted)
            lime.textSize=31f
            val days=next?.let { java.time.temporal.ChronoUnit.DAYS.between(today,it.date) }
            c.drawText(when { next==null -> "শুভকামনা!"; days==0L -> "আজ পরীক্ষা"; else -> "আর $days দিন বাকি" },cw/2,top+174f,lime)
            white.textSize=17f
            c.drawText("সকাল ৯:০০ – ১০:৩০",cw/2,top+215f,white)
            val upcoming=next?.let{exams.getOrNull(exams.indexOf(it)+1)}
            muted.textSize=15f
            c.drawText(upcoming?.let{"এরপর: ${it.subject} · ${it.date.format(dateFormat)}"} ?: "রুটিন অনুযায়ী",cw/2,ch*.78f,muted)
            c.drawText("প্রতিদিন স্বয়ংক্রিয় কাউন্টডাউন",cw/2,ch*.84f,muted)
            c.restore()
        }
    }
}
