ধাপ ৪: Android Live Wallpaper প্রজেক্ট (Source Scaffold)

এটি Kotlin/Android native প্রজেক্টের প্রাথমিক source scaffold; এখানে APK সরাসরি compile করা হয়নি।
APK build করতে Android SDK/Gradle পরিবেশ দরকার। Android ফোন থেকেই GitHub-এ এই ZIP আপলোড করে Actions workflow চালিয়ে debug APK artifact তৈরি করা সম্ভব, তবে সেটআপে কিছু ধাপ থাকবে।

APK ইনস্টল হলে:
1. ফোনের Settings / Wallpaper & style খুলুন।
2. Live wallpapers নির্বাচন করুন।
3. CS Exam Countdown বেছে Preview করুন।
4. Set wallpaper চাপুন।

সময়সূচি: Computer Science কলামের তথ্য মূল ছবির সঙ্গে মিলিয়ে রাখা:
6 Dec Mathematics-I, 7 Dec Bangla-I, 8 Dec English-I, 9 Dec Physics-I,
10 Dec ==, 13 Dec Basic Electricity, 14 Dec ==.
Android wallpaper service চালু থাকলে স্ক্রিন দেখানোর সময় বর্তমান তারিখ অনুযায়ী কাউন্টডাউন রেন্ডার করবে।
